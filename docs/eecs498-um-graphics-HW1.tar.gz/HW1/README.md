# EECS 498/598 Computer Graphics and Generative Models

Starter code for HW1 of EECS 498/598 Computer Graphics and Generative Models.
Reminder that all changes should be made in `rasterizer_impl.cpp`.

## Contributors

Created by [@ARessegetesStery](https://github.com/ARessegetesStery) and [@AnemoCider](https://github.com/AnemoCider).

Instructed by [Prof. Jeong Joon Park](https://jjparkcv.github.io/).
